# nsurlsession

An app which lets you query the iTunes Search AP and download 30-second previews of selected songs. Used the Tutorial from https://www.raywenderlich.com/110458/nsurlsession-tutorial-getting-started as basic. Updated to Swift 3.0

## Result

![](result.gif)
